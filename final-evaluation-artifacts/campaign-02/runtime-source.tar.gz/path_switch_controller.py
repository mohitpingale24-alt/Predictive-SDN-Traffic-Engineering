
import os
import sys
import time

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, DEAD_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib import hub

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
ML_SRC = os.path.join(PROJECT_ROOT, 'cnt-ml', 'src')
if ML_SRC not in sys.path:
    sys.path.insert(0, ML_SRC)

from predict import get_model_info, predict_future_utilization
from telemetry_runtime import (
    CONTROL_EVENT_FIELDS,
    PREDICTION_FIELDS,
    FeatureHistory,
    PortRateTracker,
    RecentRTT,
    ReroutePolicy,
    StructuredCsvRecorder,
    TelemetryCsvRecorder,
    project_path_signals,
)

PATH_FILE = '/tmp/active_path'
SWITCH_NAMES = {1: 's1', 2: 's2', 3: 's3', 4: 's4'}
S1_PATH_PORT = {'A': 2, 'B': 3}
S4_PATH_PORT = {'A': 2, 'B': 3}
S1_PORT_LINK = {2: ('A', 'S1-S2'), 3: ('B', 'S1-S3')}
MONITOR_INTERVAL_SECONDS = float(os.getenv('SDN_MONITOR_INTERVAL_SECONDS', '1'))
LINK_CAPACITY_MBPS = float(os.getenv('SDN_LINK_CAPACITY_MBPS', '10'))
PATH_CAPACITY_MBPS = {
    'A': float(os.getenv('SDN_PATH_A_CAPACITY_MBPS', str(LINK_CAPACITY_MBPS))),
    'B': float(os.getenv('SDN_PATH_B_CAPACITY_MBPS', str(LINK_CAPACITY_MBPS))),
}
CONTROL_MODE = os.getenv('SDN_CONTROL_MODE', 'predictive').strip().lower()
TELEMETRY_PATH = os.getenv(
    'SDN_TELEMETRY_CSV',
    os.path.join(PROJECT_ROOT, 'cnt-ml', 'data', 'raw', 'telemetry_live.csv'),
)
PREDICTIONS_PATH = os.getenv(
    'SDN_PREDICTIONS_CSV',
    os.path.join(PROJECT_ROOT, 'cnt-ml', 'results', 'live_predictions.csv'),
)
CONTROL_EVENTS_PATH = os.getenv(
    'SDN_CONTROL_EVENTS_CSV',
    os.path.join(PROJECT_ROOT, 'cnt-ml', 'results', 'control_events.csv'),
)


class PathSwitchController(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(PathSwitchController, self).__init__(*args, **kwargs)
        self.active_path = 'A'
        self.datapaths = {}
        self.flow_counts = {}
        self.latest_utilizations = {}
        self.latest_utilization_times = {}
        self.latest_predictions = {}
        self.latest_prediction_times = {}
        self.last_control_signals = {}
        self.rate_tracker = PortRateTracker()
        self.feature_history = FeatureHistory()
        self.rtt = RecentRTT(os.getenv('SDN_PING_LOG'))
        self.telemetry_recorder = TelemetryCsvRecorder(TELEMETRY_PATH)
        self.prediction_recorder = StructuredCsvRecorder(PREDICTIONS_PATH, PREDICTION_FIELDS)
        self.control_event_recorder = StructuredCsvRecorder(CONTROL_EVENTS_PATH, CONTROL_EVENT_FIELDS)
        if CONTROL_MODE not in {'static', 'reactive', 'predictive'}:
            raise ValueError("SDN_CONTROL_MODE must be static, reactive, or predictive")
        self.reroute_policy = ReroutePolicy(
            congestion_threshold=float(os.getenv('SDN_CONGESTION_THRESHOLD', '85')),
            recovery_threshold=float(os.getenv('SDN_RECOVERY_THRESHOLD', '70')),
            minimum_improvement=float(os.getenv('SDN_MINIMUM_IMPROVEMENT', '5')),
            consecutive_samples=int(os.getenv('SDN_CONSECUTIVE_PREDICTIONS', '3')),
            cooldown_seconds=float(os.getenv('SDN_REROUTE_COOLDOWN_SECONDS', '15')),
        )
        with open(PATH_FILE, 'w') as f:
            f.write(self.active_path)
        model_info = get_model_info()
        self.active_model = model_info['active_model']
        self.logger.info(
            "Control mode=%s model=%s configured=%s horizon=%ss telemetry=%s",
            CONTROL_MODE, model_info['active_model'], model_info['configured_model'],
            model_info['prediction_horizon_seconds'], TELEMETRY_PATH,
        )
        self.control_event_recorder.append({
            'timestamp': time.time(), 'event': 'controller_start',
            'control_mode': CONTROL_MODE, 'old_path': '', 'new_path': self.active_path,
            'signal_a': '', 'signal_b': '',
            'reason': 'development default uses persistence unless SDN_ACTIVE_MODEL is set',
        })
        self.logger.info("Delay uses causal ping RTT, maximum age 1.5 seconds; uncovered learned inference is skipped")
        self.path_file_thread = hub.spawn(self._monitor_path_file)
        self.telemetry_thread = hub.spawn(self._monitor_telemetry)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        dpid = datapath.id
        self.datapaths[dpid] = datapath
        name = SWITCH_NAMES.get(dpid, dpid)
        self.logger.info("Switch connected: %s (dpid=%s)", name, dpid)
        self.add_flow(datapath, 0, self._match(datapath), self._actions_output(datapath, datapath.ofproto.OFPP_CONTROLLER))
        if dpid == 1:
            self._install_s1_flows(datapath)
        elif dpid == 4:
            self._install_s4_flows(datapath)
        elif dpid in (2, 3):
            self._install_passthrough_flows(datapath)

    @set_ev_cls(ofp_event.EventOFPStateChange, [MAIN_DISPATCHER, DEAD_DISPATCHER])
    def state_change_handler(self, ev):
        datapath = ev.datapath
        if ev.state == MAIN_DISPATCHER:
            self.datapaths[datapath.id] = datapath
        elif ev.state == DEAD_DISPATCHER:
            self.datapaths.pop(datapath.id, None)

    def _install_s1_flows(self, datapath):
        out_port = S1_PATH_PORT[self.active_path]
        self.add_flow(datapath, 10, self._match(datapath, in_port=1), self._actions_output(datapath, out_port))
        self.add_flow(datapath, 10, self._match(datapath, in_port=2), self._actions_output(datapath, 1))
        self.add_flow(datapath, 10, self._match(datapath, in_port=3), self._actions_output(datapath, 1))

    def _install_s4_flows(self, datapath):
        out_port = S4_PATH_PORT[self.active_path]
        self.add_flow(datapath, 10, self._match(datapath, in_port=1), self._actions_output(datapath, out_port))
        self.add_flow(datapath, 10, self._match(datapath, in_port=2), self._actions_output(datapath, 1))
        self.add_flow(datapath, 10, self._match(datapath, in_port=3), self._actions_output(datapath, 1))

    def _install_passthrough_flows(self, datapath):
        self.add_flow(datapath, 10, self._match(datapath, in_port=1), self._actions_output(datapath, 2))
        self.add_flow(datapath, 10, self._match(datapath, in_port=2), self._actions_output(datapath, 1))

    def _match(self, datapath, **kwargs):
        parser = datapath.ofproto_parser
        return parser.OFPMatch(**kwargs)

    def _actions_output(self, datapath, port):
        parser = datapath.ofproto_parser
        return [parser.OFPActionOutput(port)]

    def add_flow(self, datapath, priority, match, actions):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, priority=priority, match=match, instructions=inst)
        datapath.send_msg(mod)

    def modify_flow(self, datapath, priority, match, actions):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS, actions)]
        mod = parser.OFPFlowMod(datapath=datapath, command=ofproto.OFPFC_MODIFY_STRICT, priority=priority, match=match, instructions=inst)
        datapath.send_msg(mod)

    def _monitor_path_file(self):
        while True:
            hub.sleep(2)
            try:
                with open(PATH_FILE, 'r') as f:
                    requested = f.read().strip().upper()
            except FileNotFoundError:
                continue
            if requested in ('A', 'B') and requested != self.active_path:
                self.logger.info("Path change requested: %s -> %s", self.active_path, requested)
                self.switch_path(requested, reason='manual path file')

    def _monitor_telemetry(self):
        while True:
            for datapath in list(self.datapaths.values()):
                self._request_stats(datapath)
            hub.sleep(MONITOR_INTERVAL_SECONDS)

    def _request_stats(self, datapath):
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto
        datapath.send_msg(parser.OFPPortStatsRequest(datapath, 0, ofproto.OFPP_ANY))
        datapath.send_msg(parser.OFPFlowStatsRequest(datapath))

    @set_ev_cls(ofp_event.EventOFPFlowStatsReply, MAIN_DISPATCHER)
    def flow_stats_reply_handler(self, ev):
        if ev.msg.datapath.id != 1:
            return
        counts = {2: 0, 3: 0}
        for flow in ev.msg.body:
            if getattr(flow, 'priority', 0) <= 0:
                continue
            for instruction in getattr(flow, 'instructions', []):
                for action in getattr(instruction, 'actions', []):
                    port = getattr(action, 'port', None)
                    if port in counts:
                        counts[port] += 1
        self.flow_counts.update(counts)

    @set_ev_cls(ofp_event.EventOFPPortStatsReply, MAIN_DISPATCHER)
    def port_stats_reply_handler(self, ev):
        if ev.msg.datapath.id != 1:
            return
        now = time.time()
        for stat in ev.msg.body:
            if stat.port_no not in S1_PORT_LINK:
                continue
            path, link_id = S1_PORT_LINK[stat.port_no]
            sample = self.rate_tracker.observe(
                timestamp=now,
                link_id=link_id,
                capacity_mbps=PATH_CAPACITY_MBPS[path],
                rx_bytes=stat.rx_bytes,
                tx_bytes=stat.tx_bytes,
                rx_packets=stat.rx_packets,
                tx_packets=stat.tx_packets,
                rx_dropped=stat.rx_dropped,
                tx_dropped=stat.tx_dropped,
                active_flows=self.flow_counts.get(stat.port_no, 0),
            )
            if sample is None:
                continue
            rtt = self.rtt.at(now)
            sample['delay'] = rtt if rtt is not None else ''
            self.telemetry_recorder.append(sample)
            self.latest_utilizations[path] = sample['utilization']
            self.latest_utilization_times[path] = now
            features = self.feature_history.update(sample)
            history_count = self.feature_history.count(link_id)
            if features is None:
                self.prediction_recorder.append({
                    'timestamp': now, 'control_mode': CONTROL_MODE,
                    'active_path': self.active_path, 'path': path, 'link_id': link_id,
                    'history_count': history_count,
                    'prediction_status': 'skipped_insufficient_history',
                    'current_utilization': sample['utilization'],
                    'signal_utilization': '', 'predicted_utilization': '',
                    'inference_time_ms': '',
                })
                self.logger.info(
                    "Telemetry %s history_count=%s prediction=SKIPPED (requires 11 samples)",
                    link_id, history_count,
                )
                continue
            if CONTROL_MODE != 'predictive':
                self.prediction_recorder.append({
                    'timestamp': now, 'control_mode': CONTROL_MODE,
                    'active_path': self.active_path, 'path': path, 'link_id': link_id,
                    'history_count': history_count,
                    'prediction_status': 'observed_signal_after_warmup',
                    'current_utilization': sample['utilization'],
                    'signal_utilization': sample['utilization'],
                    'predicted_utilization': sample['utilization'],
                    'inference_time_ms': 0.0,
                })
                continue
            if rtt is None and self.active_model != 'persistence':
                self.prediction_recorder.append({
                    'timestamp': now, 'control_mode': CONTROL_MODE,
                    'active_path': self.active_path, 'path': path, 'link_id': link_id,
                    'history_count': history_count, 'prediction_status': 'skipped_missing_rtt',
                    'current_utilization': sample['utilization'],
                    'signal_utilization': '', 'predicted_utilization': '',
                    'inference_time_ms': '',
                })
                continue
            try:
                inference_start = time.perf_counter()
                prediction = predict_future_utilization(features)
                inference_time_ms = (time.perf_counter() - inference_start) * 1000
            except Exception as error:
                self.logger.exception("Prediction failed for %s: %s", link_id, error)
                continue
            self.latest_predictions[path] = prediction
            self.latest_prediction_times[path] = now
            self.prediction_recorder.append({
                'timestamp': now, 'control_mode': CONTROL_MODE,
                'active_path': self.active_path, 'path': path, 'link_id': link_id,
                'history_count': history_count,
                'prediction_status': 'predicted',
                'current_utilization': sample['utilization'],
                'signal_utilization': prediction,
                'predicted_utilization': prediction,
                'inference_time_ms': inference_time_ms,
            })
            self.logger.info(
                "Telemetry %s current=%.2f%% predicted_t+5=%.2f%%",
                link_id, sample['utilization'], prediction,
            )
        self._evaluate_reroute(now)

    def _evaluate_reroute(self, now):
        if CONTROL_MODE == 'static':
            return
        if CONTROL_MODE == 'reactive':
            signals = self.latest_utilizations
            signal_times = self.latest_utilization_times
        else:
            signals = self.latest_predictions
            signal_times = self.latest_prediction_times
        if not {'A', 'B'}.issubset(signals):
            return
        freshness_limit = max(3.0, MONITOR_INTERVAL_SECONDS * 3)
        if any(now - signal_times[path] > freshness_limit for path in ('A', 'B')):
            return
        projected_signals = project_path_signals(self.active_path, signals, PATH_CAPACITY_MBPS)
        self.last_control_signals = projected_signals
        new_path = self.reroute_policy.evaluate(self.active_path, projected_signals, now)
        if new_path is not None:
            reason = (
                "%s projected policy A=%.2f%% B=%.2f%%"
                % (CONTROL_MODE, projected_signals['A'], projected_signals['B'])
            )
            self.switch_path(new_path, reason=reason)

    def switch_path(self, new_path, reason='controller request'):
        if new_path not in ('A', 'B'):
            raise ValueError("new_path must be A or B")
        if new_path == self.active_path:
            return
        old_path = self.active_path
        self.active_path = new_path
        s1 = self.datapaths.get(1)
        s4 = self.datapaths.get(4)
        if s1:
            out_port = S1_PATH_PORT[new_path]
            self.modify_flow(s1, 10, self._match(s1, in_port=1), self._actions_output(s1, out_port))
            self.logger.info("s1 updated: h1 traffic now -> port %s (%s)", out_port, 's2' if out_port == 2 else 's3')
        if s4:
            out_port = S4_PATH_PORT[new_path]
            self.modify_flow(s4, 10, self._match(s4, in_port=1), self._actions_output(s4, out_port))
            self.logger.info("s4 updated: h2 traffic now -> port %s (%s)", out_port, 's2' if out_port == 2 else 's3')
        with open(PATH_FILE, 'w') as f:
            f.write(self.active_path)
        self.control_event_recorder.append({
            'timestamp': time.time(), 'event': 'reroute',
            'control_mode': CONTROL_MODE, 'old_path': old_path, 'new_path': new_path,
            'signal_a': self.last_control_signals.get('A', ''),
            'signal_b': self.last_control_signals.get('B', ''),
            'reason': reason,
        })
        self.logger.info("Active path is now %s (%s)", new_path, reason)

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def packet_in_handler(self, ev):
        msg = ev.msg
        dpid = msg.datapath.id
        in_port = msg.match['in_port']
        self.logger.info("Packet reached controller (unmatched): dpid=%s in_port=%s", dpid, in_port)
        
